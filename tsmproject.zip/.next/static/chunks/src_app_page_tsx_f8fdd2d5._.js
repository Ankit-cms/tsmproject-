(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1ea0c15a._.js",
  "static/chunks/src_app_components_TMSLandingPage_tsx_fa85c3e4._.js"
],
    source: "dynamic"
});
