(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_5b402162._.js",
  "static/chunks/node_modules_next_app_72f3d36f.js",
  "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db4bb196._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js"
],
    source: "entry"
});
