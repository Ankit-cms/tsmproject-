import TMSLandingPage from "./components/TMSLandingPage";

export default function Home() {
  return <TMSLandingPage />;
}