"use client";
// pages/index.js
import React from 'react';
import {
    Box,
    Container,
    Typography,
    Button,
    Card,
    CardContent,
    AppBar,
    Toolbar,
    IconButton,
    Paper,
    TextField,
    Chip,
    Avatar,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Divider,
    Stack,
    useTheme,
    useMediaQuery
} from '@mui/material';
import { Grid } from '@mui/material';
import {
    Phone,
    Email,
    LocationOn,
    CheckCircle,
    TrendingUp,
    Visibility,
    Groups,
    Analytics,
    Receipt,
    Notifications,
    Dashboard,
    DocumentScanner,
    IntegrationInstructions,
    DataUsage,
    Smartphone,
    Public,
    Speed
} from '@mui/icons-material';

const TMSLandingPage = () => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));

    return (
        <Box>
            <AppBar position="static" color="default" elevation={1}>
                <Toolbar>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
                        TMS solutions
                    </Typography>
                    <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 2 }}>
                        <Button color="inherit">Pricing</Button>
                        <Button color="inherit">Contact us</Button>
                        <Button variant="contained" color="primary">
                            Get Demo
                        </Button>
                    </Box>
                    <IconButton color="inherit" sx={{ display: { md: 'none' } }}>
                        <Phone />
                    </IconButton>
                </Toolbar>
            </AppBar>

            <Container maxWidth="lg" sx={{ py: 8 }}>
                <Box sx={{
                    display: 'flex',
                    flexDirection: { xs: 'column', md: 'row' },
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 4,
                    mb: 8
                }}>
                    <Box sx={{
                        flex: '0 1 50%',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'center'
                    }}>
                        <Typography variant="h3" component="h1" gutterBottom fontWeight="bold">
                            Transport management system
                        </Typography>
                        <Typography variant="h6" color="text.secondary" paragraph>
                            Cloud-based SaaS TMS and visibility platform for 3PLs, Shippers, LSPs, Transporters, and Carriers,
                            enabling end-to-end efficient transportation logistics operations and collaboration
                        </Typography>
                        <Button variant="contained" size="large" sx={{ mt: 2, alignSelf: 'flex-start' }}>
                            Schedule a Demo
                        </Button>
                    </Box>

                </Box>
                <Box sx={{
                    mb: 6
                }}>
                    <Box >
                        <Typography variant="h5" gutterBottom color="text.primary">
                            Instalanes TMS - the all-in-one unified platform for transportation logistics
                        </Typography>
                        <Typography variant="h4" >
                            Simplify and digitize FCL, FTL, PTL, ODC, and warehouse shipments with a unified
                            TMS for Shippers, Carriers, 3PLs, and LSPs
                        </Typography>
                    </Box>
                </Box>
                <Box sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    gap: 2,
                    justifyContent: 'center'
                }}>
                    {[
                        { number: 1, title: 'Dispatch planner', icon: <Dashboard /> },
                        { number: 2, title: 'Transport order', icon: <Receipt /> },
                        { number: 3, title: 'Rates and Carrier', icon: <Analytics /> },
                        { number: 4, title: 'Shipments and tracking', icon: <Visibility /> },
                        { number: 5, title: 'PoD and Billing', icon: <DocumentScanner /> },
                        { number: 6, title: 'Reporting Intelligence', icon: <DataUsage /> }
                    ].map((feature, index) => (
                        <Box
                            key={index}
                            sx={{
                                flex: '1 1 calc(16.666% - 16px)',
                                minWidth: { xs: 'calc(50% - 16px)', sm: 'calc(33.333% - 16px)', md: 'calc(16.666% - 16px)' },
                                maxWidth: { xs: 'calc(50% - 16px)', sm: 'calc(33.333% - 16px)', md: 'calc(16.666% - 16px)' }
                            }}
                        >
                            <Card elevation={2} sx={{ height: '100%' }}>
                                <CardContent sx={{ textAlign: 'center', p: 2 }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'center', mb: 1 }}>
                                        {feature.icon}
                                    </Box>
                                    <Typography variant="h6" gutterBottom color="primary">
                                        {feature.number}
                                    </Typography>
                                    <Typography variant="body1" sx={{ fontSize: '0.9rem', fontWeight: 'medium' }}>
                                        {feature.title}
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Box>
                    ))}
                </Box>
            </Container>

            <Container maxWidth="lg" sx={{ py: 8 }}>
                <Box sx={{ mb: 6 }}>
                    <Typography variant="h5" component="h2" gutterBottom color="primary">
                        Why Instalanes platform
                    </Typography>
                    <Typography variant="h4" >
                        Instalanes is a Collaborative TMS platform that helps Business leaders generate real business outcomes, they care for!
                    </Typography>
                </Box>
                <Box sx={{
                    display: 'flex',
                    flexDirection: { xs: 'column', md: 'row' },
                    flexWrap: 'wrap',
                    gap: 3,
                    justifyContent: 'center',
                    alignItems: 'stretch'
                }}>
                    {[
                        {
                            value: '9x',
                            title: 'Visibility',
                            description: 'Nine-layered visibility gives you unmatched control and understanding of what\'s happening on your network. See everything at a glance.'
                        },
                        {
                            value: '100%',
                            title: 'Collaboration',
                            description: 'Boost your teams productivity and experience. Empower your team, enhance effectiveness of your teams.'
                        },
                        {
                            value: '~30%',
                            title: 'Optimization',
                            description: 'By digitizing your processes, you can eliminate manual tasks and standardize your operations to lower costs.'
                        },
                    ].map((stat, index) => (
                        <Box
                            key={index}
                            sx={{
                                flex: { xs: '1 1 100%', md: '1 1 calc(25% - 12px)' },
                                minWidth: { xs: '100%', md: 'calc(25% - 12px)' }
                            }}
                        >
                            <Card elevation={3} sx={{ height: '100%' }}>
                                <CardContent sx={{ p: 3, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column' }}>
                                    <Typography variant="h3" component="div" color="primary" fontWeight="bold" gutterBottom>
                                        {stat.value}
                                    </Typography>
                                    <Typography variant="h6" component="h3" gutterBottom fontWeight="medium">
                                        {stat.title}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary" sx={{ flexGrow: 1, lineHeight: 1.5 }}>
                                        {stat.description}
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Box>
                    ))}
                </Box>
            </Container>
            <Container maxWidth="lg" sx={{ py: 8 }}>
                <Typography variant="h5" component="h6" gutterBottom >
                    Solving the big challenge
                </Typography>
                <Typography variant="h4" component="h4" gutterBottom >
                    Simplifying the complex manual chaos, digitally
                </Typography>
                <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
                    What Supply Chain leaders want .. ?
                </Typography>
                <Typography paragraph>
                    Efficient and visible supply chain management is the goal of every business leader. Having a clear understanding of the supply chain and being able to track it in real time is critical for running a successful operation and expanding the business.
                </Typography>
                <Box display="flex" flexDirection={isMobile ? 'column' : 'row'} gap={4} width="100%" alignItems="center" justifyContent="center" sx={{ mt: 4 }}>
                    <Box>
                        <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
                            The challenge
                        </Typography>
                        <Typography paragraph>
                            However, managing the supply chain and maintaining visibility across all teams, systems, documents, and process handoffs is extremely complex. Organizations are still relying on emails and phone calls to manage and track.
                        </Typography>
                        <Typography paragraph>
                            This leads to a complex way of working, additional logistics costs, poor experience, and low operational control.
                        </Typography>
                    </Box>
                    <Box> <img src="/img/before.png" alt="TMS Illustration" width={800} height={400} style={{ width: '100%', height: 'auto' }} /> </Box>
                </Box>
                <Box display="flex" flexDirection={isMobile ? 'column' : 'row'} gap={4} width="100%" alignItems="center" justifyContent="center" sx={{ mt: 4 }}>
                    <Box> <img src="/img/after.png" alt="TMS Illustration" width={800} height={400} style={{ width: '100%', height: 'auto' }} /> </Box>
                    <Box>
                        <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
                            The Digital Solution
                        </Typography>
                        <Typography paragraph>
                            Currently, there is a need to have an impactful global platform that is easy, smart, and accessible by the masses that keeps everyone on the same page.
                        </Typography>
                        <Typography paragraph>
                            Instalanes platform enhances the ability of supply chain leaders and their teams to make transportation logistics a competitive advantage. With the value proposition offered, your teams can deliver real impact on business outcomes
                        </Typography>
                    </Box>
                </Box>
            </Container>
            <Container maxWidth="lg" sx={{ py: 8 }}>
                <Typography variant="h4" component="h2" gutterBottom fontWeight="bold">
                    Digital TMS platform solutions
                </Typography>
                <Typography variant="h4" component="h2" gutterBottom >
                    Instalanes digitizes your entire transportation process, solving real industry challenges
                </Typography>
                <Grid container spacing={4} mt={2}>
                    <img src="/img/Instalanes-TMS-Process.svg" alt="TMS Illustration" width={800} height={400} style={{ width: '100%', height: 'auto' }} />
                </Grid>
            </Container>
            <Box component="footer" sx={{ bgcolor: 'grey.100', py: 6 }}>
                <Container maxWidth="lg">
                    <Box>
                        <Typography variant="h6" gutterBottom fontWeight="bold">
                            Installanes
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                            Instalanes is a Transport management and visibility platform that helps businesses improve their supply chain visibility, collaboration, growth, and efficiency. The platform helps users to manage and track their supply chain, as well as to access performance insights that help teams make better decisions.
                        </Typography>
                    </Box>
                    <Box sx={{
                        display: 'flex',
                        flexDirection: { xs: 'column', md: 'row' },
                        gap: 4,
                        mb: 4
                    }}>
                        <Box sx={{ flex: 1 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                Company
                            </Typography>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                                {['About', 'Careers', 'Terms', 'Privacy policy'].map((item) => (
                                    <Typography
                                        key={item}
                                        variant="body2"
                                        color="text.secondary"
                                        sx={{ cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                                    >
                                        {item}
                                    </Typography>
                                ))}
                            </Box>
                        </Box>

                        <Box sx={{ flex: 1 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                TMS Capabilities
                            </Typography>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                                {['Consulting', 'Data analytics', 'Business intelligence', 'Process automation'].map((item) => (
                                    <Typography
                                        key={item}
                                        variant="body2"
                                        color="text.secondary"
                                        sx={{ cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                                    >
                                        {item}
                                    </Typography>
                                ))}
                            </Box>
                        </Box>

                        <Box sx={{ flex: 1 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                Resources
                            </Typography>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 3 }}>
                                {['Blogs', 'Partnering', 'Pricing - Get Quote', 'Pay here'].map((item) => (
                                    <Typography
                                        key={item}
                                        variant="body2"
                                        color="text.secondary"
                                        sx={{ cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                                    >
                                        {item}
                                    </Typography>
                                ))}
                            </Box>
                        </Box>

                        <Box sx={{ flex: 1 }}>
                            <Typography variant="h6" gutterBottom fontWeight="bold">
                                Contact
                            </Typography>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                                {['Email', 'Phone'].map((item) => (
                                    <Typography
                                        key={item}
                                        variant="body2"
                                        color="text.secondary"
                                        sx={{ cursor: 'pointer', '&:hover': { color: 'primary.main' } }}
                                    >
                                        {item}
                                    </Typography>
                                ))}
                            </Box>
                        </Box>
                    </Box>
                    <Box sx={{
                        display: 'flex',
                        flexDirection: { xs: 'column', sm: 'row' },
                        justifyContent: 'space-between',
                        alignItems: { xs: 'flex-start', sm: 'center' },
                        gap: 2,
                        pt: 3,
                        borderTop: 1,
                        borderColor: 'divider'
                    }}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                            <Typography variant="body2" color="text.secondary">
                                Gravity44/ Copyright © 2024 Installanes.com. All rights reserved.
                            </Typography>
                        </Box>
                    </Box>
                </Container>
            </Box>
        </Box>
    );
};

export default TMSLandingPage;